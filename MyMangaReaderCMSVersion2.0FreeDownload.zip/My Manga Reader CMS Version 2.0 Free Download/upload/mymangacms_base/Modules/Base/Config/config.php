<?php

return [
    'name' => 'Base'
];
