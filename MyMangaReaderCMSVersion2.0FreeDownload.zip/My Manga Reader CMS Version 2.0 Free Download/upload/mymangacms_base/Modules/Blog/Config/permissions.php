<?php

return [
    'blog' => [
        'manage_posts' => 'Manage Posts',
        'manage_pages' => 'Manage Pages',
    ],
];
